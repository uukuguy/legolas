#ifndef BENCHMARKS_HPP
#define BENCHMARKS_HPP

#include "celero/Celero.h"

#endif // BENCHMARKS_HPP
