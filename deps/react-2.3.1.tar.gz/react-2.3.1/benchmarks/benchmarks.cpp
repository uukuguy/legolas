#include "benchmarks.hpp"
CELERO_MAIN
