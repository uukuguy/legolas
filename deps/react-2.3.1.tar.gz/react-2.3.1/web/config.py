__author__ = 'acid'

CSRF_ENABLED = True
SECRET_KEY = 'React-dashboard-secret-key'