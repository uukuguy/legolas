Visual Studio product and C++ compiler Versions:

Visual C++ 2008 => Visual C++ 9
Visual C++ 2010 => Visual C++ 10
Visual C++ 2012 => Visual C++ 11
Visual C++ 2013 => Visual C++ 12

Note that solution file icons reflect the compiler version ([9], [10], [11], [12]), not the product version.

The vs2013/vs2012/vs2010 solution and project files differ only in versioning.

More info here:

http://en.wikipedia.org/wiki/Visual_C%2B%2B
