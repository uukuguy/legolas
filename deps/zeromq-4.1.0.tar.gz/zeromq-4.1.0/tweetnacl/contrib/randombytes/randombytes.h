
#ifndef randombytes_H
#define randombytes_H
#include "devurandom.h"
#endif
