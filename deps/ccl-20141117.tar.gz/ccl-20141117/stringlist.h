#undef CHARTYPE
#undef DATA_TYPE
#define CHARTYPE char
#define DATA_TYPE String
#include "stringlistgen.h"
