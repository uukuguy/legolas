#include "containers.h"
#undef DATA_TYPE
#define DATA_TYPE size_t
#include "vectorgen.c"
