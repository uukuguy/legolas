About
=====
Eblob is an append-only low-level IO library, which saves data in blob files.
It was originally created for elliptics distributed storage as low-level backend.

Docs
====
Reverbrain wiki: http://doc.reverbrain.com/eblob:eblob

Status
======
.. image:: https://secure.travis-ci.org/reverbrain/eblob.png?branch=master
   :target: https://travis-ci.org/reverbrain/eblob

Links
=====
| Homepage: http://www.reverbrain.com/eblob/
| Elliptics: http://www.reverbrain.com/elliptics/
| Google group: https://groups.google.com/forum/?fromgroups=#!forum/reverbrain
